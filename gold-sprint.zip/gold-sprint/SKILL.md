---
name: gold-sprint
description: >
  Multi-agent software development workflow for large, complex codebases. Use this skill whenever the user wants to plan and build a feature end-to-end with structured phases: ideation, technical planning, coding, verification, and testing. Triggers on phrases like "let's build X", "implement feature Y", "tôi muốn làm tính năng", "bắt đầu sprint", "new gold", "new sprint", "triển khai", or when the user describes a software feature and wants it implemented with quality gates. Also use when the user wants to manage ongoing sprints, review sprint results, or continue an existing gold.
---

# Gold Sprint Skill

A structured multi-agent workflow for developing software features on large codebases — with quality gates, human confirmation checkpoints, and full traceability across sprints.

## Core Concepts

- **Gold**: A large feature or milestone, typically 3–4 sprints. Has its own folder.
- **Sprint**: One complete development cycle within a Gold. Produces concrete, testable output.
- **Phase**: A named agent role within a sprint. Phases run sequentially; each hands off to the next.

## Folder Structure

```
gold_<N>_<slug>/
├── gold_brief.md           ← Written by Main at Gold kickoff
├── gold_summary.md         ← Written by Main at Gold completion
└── sprint_<N>/
    ├── plan.md             ← Planner output: technical plan
    ├── test_key.md         ← Planner output: test cases + scoring rubric
    ├── report.md           ← Tester output: score + pass/fail per test
    ├── coder_response.md   ← Coder's explanation of failed items
    └── sprint_summary.md   ← Main's final assessment, sent to user
```

---

## Phase Roles

### 1. MAIN (Orchestrator)

Main is the first and last phase of every sprint. It coordinates all other phases and is the sole point of contact with the user.

**At Gold kickoff**, Main:
- Asks the user to describe their idea in enough detail to plan technically
- Clarifies: what is the end result? what does "done" look like? any constraints?
- Writes `gold_brief.md` once confirmed
- Passes the brief to Planner

**At Sprint start**, Main:
- Summarizes what this sprint will tackle (scope within the Gold)
- Hands off to Planner

**At Sprint end**, Main:
- Reads `report.md` (from Tester) and `coder_response.md` (from Coder)
- Writes `sprint_summary.md`: what passed, what failed, why, and recommendation (proceed / fix / escalate)
- Presents the summary to the user clearly and concisely
- Asks the user: start next sprint? pause? adjust scope?

**Main never skips user confirmation** before starting a new sprint or Gold.

---

### 2. PLANNER (Technical Architect)

Planner receives the Gold brief + sprint scope and produces two files:

**`plan.md`** — Technical plan, must include:
- What will be built this sprint (precise scope)
- Architecture decisions and rationale
- File/module breakdown: what gets created or modified
- Dependencies, risks, known tradeoffs
- Step-by-step implementation sequence

**`test_key.md`** — Test specification, must include:
- List of test cases (minimum 3, maximum 10 per sprint)
- For each test case: input, expected output, pass criteria
- Scoring rubric: each test case carries a weight (weights sum to 100%)
- Edge cases that are explicitly out of scope this sprint

**When Planner must pause and escalate to Main (who asks the user):**
- Any architectural decision with significant tradeoffs (e.g., two valid DB schema choices)
- Tech stack additions not previously mentioned
- Scope that would require touching modules flagged as sensitive
- Anything the user has previously indicated needs their sign-off

Planner should not escalate for minor decisions (variable naming, folder structure, minor implementation details). When in doubt about whether to escalate: if it affects the final result in a way the user would care about → escalate.

---

### 3. CODER (Implementer)

Coder reads `plan.md` and implements exactly what was specified. 

Rules:
- Follow the plan's step-by-step sequence
- Do not deviate from architecture decisions without flagging to Main first
- Write clean, readable code with inline comments for non-obvious logic
- If something in the plan is impossible or contradictory, stop and report to Main (do not guess)
- When done, briefly document what was implemented (in `coder_response.md` initially left as implementation notes)

---

### 4. VERIFIER (Quality Gate)

Verifier reads the code produced by Coder and checks:
- Does the implementation match `plan.md` step by step?
- Are there obvious bugs, missing error handling, or broken imports?
- Is the code ready to be tested (no syntax errors, dependencies installed, entry points clear)?
- Flag any mismatch between plan and implementation

Verifier does **not** run tests — that's Tester's job. Verifier only ensures the code is structurally sound and testable. If Verifier finds critical issues, it reports back to Coder for a fix before Tester runs.

---

### 5. TESTER (Evaluator)

Tester reads `test_key.md` and executes each test case against the code.

**For each test case:**
- Run or simulate the test
- Record: pass / fail / partial
- If partial or fail: document exactly what happened vs. what was expected

**Scoring:**
- Each test case has a weight from `test_key.md`
- Final score = sum of (weight × pass_factor) across all test cases
- pass_factor: 1.0 = full pass, 0.5 = partial, 0.0 = fail

**`report.md` format:**
```
# Sprint Report — Sprint <N>

## Score: <X>%

## Test Results
| # | Test Case | Weight | Result | Notes |
|---|-----------|--------|--------|-------|
| 1 | ... | 20% | ✅ Pass | |
| 2 | ... | 30% | ❌ Fail | Expected X, got Y |
| 3 | ... | 50% | ⚠️ Partial | ... |

## Failed / Partial Details
[For each non-passing test: what exactly failed and why]
```

After writing `report.md`, Tester sends the failed/partial list to Coder.

---

### CODER (Response to Tester)

After receiving Tester's report, Coder writes `coder_response.md`:
- For each failed/partial test: explain why it failed (root cause)
- State whether it's fixable in next sprint or needs Planner re-scoping
- Do NOT re-implement in this phase — this is analysis only

---

## Sprint Execution Checklist

Run phases in this exact order. Do not skip steps.

```
[ ] Main: Confirm sprint scope with user (or Gold kickoff)
[ ] Planner: Write plan.md — escalate to Main if needed
[ ] Main: If escalated, confirm with user before Planner continues
[ ] Planner: Write test_key.md
[ ] Coder: Implement per plan.md
[ ] Verifier: Check code quality and testability — send back to Coder if critical issues found
[ ] Tester: Run test_key.md, write report.md (score 0–100%)
[ ] Coder: Write coder_response.md (analysis of failures)
[ ] Main: Write sprint_summary.md, present to user
[ ] Main: Ask user — next sprint? adjust? pause?
```

---

## Starting a New Gold

When the user wants to start something new:

1. Main asks: "Bạn muốn xây dựng gì? Mô tả ý tưởng — kết quả cuối là gì, constraints là gì?"
2. User describes idea
3. Main asks clarifying questions until the brief is technically clear
4. Main writes `gold_brief.md` and presents it: "Đây là brief — xác nhận để bắt đầu Sprint 1?"
5. User confirms → Sprint 1 begins

`gold_brief.md` must include:
- Feature/goal description
- Technical constraints (language, framework, existing modules to touch)
- Definition of done for the entire Gold
- Sensitive areas requiring user sign-off before Planner decides

---

## Continuing an Existing Gold

If the user refers to an existing Gold:
1. Main reads `gold_brief.md` and the last `sprint_summary.md`
2. Summarizes current state to user
3. Proposes next sprint scope
4. User confirms → sprint begins

---

## Communication Style per Phase

Each phase should output in a structured, readable way:

- **Main → User**: conversational, clear summary, explicit ask ("xác nhận?")
- **Planner → files**: technical, precise, no ambiguity
- **Coder → files**: implementation notes, brief inline reasoning
- **Verifier → Coder**: direct issue list, severity (critical / minor)
- **Tester → report.md**: objective, evidence-based, no opinions
- **Coder → coder_response.md**: honest root cause analysis

---

## References

- `references/file_templates.md` — Exact templates for all output files
- `references/escalation_guide.md` — Decision tree: when Planner escalates vs. decides
